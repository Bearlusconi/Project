﻿namespace Certificati.Models
{
    public class Collegamentostudentecertificato
    {
            public string? Cfs_FK { get; set; }
            public int Idc_FK { get; set; }
            public string? Nome { get; set; }
            public int Annoscolastico { get; set; }
            public string? Classe { get; set; }
            public string? NomeCertificato { get; set; }
    }
}
