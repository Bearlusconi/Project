﻿namespace Certificati.Models
{
    public class Ottenimento
    {
        public int Chiave { get; set; }
        public string? Cfs_FK { get; set; }
        public int Idc_FK { get; set; }
    }
}
