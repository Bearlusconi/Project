﻿using Microsoft.AspNetCore.Components.Forms;
using System.ComponentModel.DataAnnotations;

namespace Certificati.Models
{
    public class Studente
    {
        [Required]
        public string? Cfs_PK { get; set; }
        [Required]
        public string? Nome { get; set; }
        [Required]
        public string? Cognome { get; set; }
        [Required]
        public string? Email { get; set; }
        [Required]
        public string? Pwd { get; set; }
        [Required]
        [Range(1, 5)]
        public int Annoscolastico { get; set; }
        [Required]
        public string? Classe { get; set; }

    }
}
