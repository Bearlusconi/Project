﻿namespace Certificati.Models
{
    public class Certificatis
    {
        public string? nomecertificato { get; set; }
        public string? tipocertificato { get; set; }
        public DateTime datarilascio { get; set; }
        public string? motivorilascio { get; set; }
        public Byte[]? img { get; set; }
    }
}
