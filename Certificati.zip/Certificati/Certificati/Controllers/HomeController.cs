using Certificati.Models;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace Certificati.Controllers
{

    public class HomeController : Controller
    {
        //stringa di connessione con i vari dati
        const string connection = "Server=localhost;Database=certificatiscolastici;User=root;Password=;";
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        //View del form
        public IActionResult InserisciStudente()
        {
            return View();
        }

        //Inserimento dati presi dal form con metodo Post
        [HttpPost]
        public IActionResult InserisciStudente(Studente s)
        {

            if (!ModelState.IsValid)
            {
                return View();
            }

            using (MySqlConnection conn = new MySqlConnection(connection))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO studenti (cfs, nome, cognome, email, pwd, annoscolastico, classe) VALUES (@cfs, @nome, @cognome, @email, @pwd, @annoscolastico, @classe)";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@cfs", s.Cfs_PK);
                    cmd.Parameters.AddWithValue("@nome", s.Nome);
                    cmd.Parameters.AddWithValue("@cognome", s.Cognome);
                    cmd.Parameters.AddWithValue("@email", s.Email);
                    cmd.Parameters.AddWithValue("@pwd", s.Pwd);
                    cmd.Parameters.AddWithValue("@annoscolastico", s.Annoscolastico);
                    cmd.Parameters.AddWithValue("@classe", s.Classe);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            return RedirectToAction("Datistudenti");
        }
        //Visualizzazione dati dello studente presi dal DB e messi in ordine 
        public IActionResult Datistudenti()
        {
            var list = new List<Studente>();
            MySqlConnection conn = new MySqlConnection(connection);

            try
            {
                conn.Open();
                string query = "SELECT * FROM studenti";

                MySqlCommand cmd = new MySqlCommand(query, conn);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Studente s = new Studente();
                        s.Cfs_PK = reader["Cfs"].ToString();
                        s.Nome = reader["Nome"].ToString();
                        s.Cognome = reader["Cognome"].ToString();
                        s.Email = reader["Email"].ToString();
                        s.Annoscolastico = Convert.ToInt32(reader["Annoscolastico"]);
                        s.Classe = reader["Classe"].ToString();
                        list.Add(s);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            return View(list);
        }
        //View per mostrere i certificati che la scuola ha da offrire
        public IActionResult MostraCertificati()
        {
            var list = new List<Certificatis>();
            MySqlConnection conn = new MySqlConnection(connection);

            try
            {
                conn.Open();
                string query = "SELECT * FROM certificati";

                MySqlCommand cmd = new MySqlCommand(query, conn);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Certificatis c = new Certificatis();
                        c.nomecertificato = reader["nomecertificato"].ToString();
                        c.tipocertificato = reader["tipocertificato"].ToString();
                        c.datarilascio = Convert.ToDateTime(reader["datarilascio"]);
                        c.motivorilascio = reader["motivorilascio"].ToString();
						c.img = (byte[])reader["immagine"];
						list.Add(c);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            return View(list);
        }
        
        //Visualizzazione degli studenti con i certificati che hanno
        public IActionResult Collegamento()
        {
            var list = new List<Collegamentostudentecertificato>();
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connection))
                {
                    conn.Open();

                    string query = @"SELECT ottenimento.cfs_fk, ottenimento.idc_fk, certificati.nomecertificato, studenti.cfs, studenti.nome, studenti.annoscolastico, studenti.classe
                    FROM ottenimento
                    JOIN certificati ON ottenimento.idc_fk = certificati.idc
                    JOIN studenti ON ottenimento.cfs_fk = studenti.cfs
                    Order by certificati.nomecertificato";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        try
                        {
                            using (MySqlDataReader reader = cmd.ExecuteReader())
                            {
                                while (reader.Read())
                                {
                                    Collegamentostudentecertificato item = new Collegamentostudentecertificato();
                                    item.Cfs_FK = reader["cfs_fk"].ToString();
                                    item.Nome = reader["Nome"].ToString();
                                    item.Annoscolastico = Convert.ToInt32(reader["Annoscolastico"]);
                                    item.Classe = reader["Classe"].ToString();
                                    item.NomeCertificato = reader["nomecertificato"].ToString();
                                    item.Idc_FK = Convert.ToInt32(reader["idc_fk"]);
                                    list.Add(item);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.ToString());
                        }

                    }
                }
                return View(list);
            }
            finally
            {
                Console.WriteLine("200");
            }
        }

       /* 
        public IActionResult VeroCollegamento()
        {
            return View();
        }
       */
        public IActionResult InserimentoCertificati()
        {
            return View();
        }

        [HttpPost]
        public IActionResult InserimentoCertificati(Certificatis c)
        {

            if (!ModelState.IsValid)
            {
                return View();
            }

            using (MySqlConnection conn = new MySqlConnection(connection))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO `certificati`(`nomecertificato`, `tipocertificato`, `datarilascio`, `motivorilascio`) VALUES (@nomecertificato, @tipocertificato, @datarilascio, @motivorilascio)";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@nomecertificato", c.nomecertificato);
                    cmd.Parameters.AddWithValue("@tipocertificato", c.tipocertificato);
                    cmd.Parameters.AddWithValue("@datarilascio", c.datarilascio);
                    cmd.Parameters.AddWithValue("@motivorilascio", c.motivorilascio);
                    cmd.Parameters.AddWithValue("@immagine", c.img);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            return RedirectToAction("MostraCertificati");


        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
