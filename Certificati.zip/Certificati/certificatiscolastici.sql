-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mar 25, 2024 alle 22:23
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `certificatiscolastici`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `certificati`
--

CREATE TABLE `certificati` (
  `idc` int(11) NOT NULL,
  `nomecertificato` varchar(255) DEFAULT NULL,
  `tipocertificato` varchar(255) DEFAULT NULL,
  `datarilascio` datetime DEFAULT NULL,
  `motivorilascio` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `certificati`
--

INSERT INTO `certificati` (`idc`, `nomecertificato`, `tipocertificato`, `datarilascio`, `motivorilascio`) VALUES
(1, 'PI Idea', 'Certicato di partecipazione', '2024-02-12 08:30:00', 'Partecipazione al pon scolastico \"PI Idea\"'),
(2, 'Introduction to Cybersecurity', 'Completamento corso', '2023-05-24 00:00:00', 'Certificato dato per aver completato il corso di Cisco Network Academy'),
(4, 'Certificatotest', 'Partecipazione', '2023-08-22 20:50:00', 'Test test');

-- --------------------------------------------------------

--
-- Struttura della tabella `ottenimento`
--

CREATE TABLE `ottenimento` (
  `chiave` int(11) NOT NULL,
  `idc_fk` int(11) DEFAULT NULL,
  `cfs_fk` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ottenimento`
--

INSERT INTO `ottenimento` (`chiave`, `idc_fk`, `cfs_fk`) VALUES
(1, 1, 'CSCGZN05M22L845S'),
(2, 1, 'MRTGPP05T14L845U'),
(6, 2, 'SMNSST05C21L845X');

-- --------------------------------------------------------

--
-- Struttura della tabella `studenti`
--

CREATE TABLE `studenti` (
  `cfs` varchar(16) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `cognome` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `pwd` varchar(255) DEFAULT NULL,
  `annoscolastico` int(11) DEFAULT NULL,
  `classe` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `studenti`
--

INSERT INTO `studenti` (`cfs`, `nome`, `cognome`, `email`, `pwd`, `annoscolastico`, `classe`) VALUES
('CSCGZN05M22L845S', 'Graziano', 'Coscarelli', 'coscarelli.graziano.s@itirenatoelia.edu.it', 'Graziano05@', 5, 'E'),
('MRTGPP05T14L845U', 'Giuseppe', 'Martino', 'martino.giuseppe.s@itirenatoelia.edu.it', 'Martino@05', 5, 'E'),
('SMNSST05C21L845X', 'Simone', 'Esposito', 'Simone@Email.com', 'Simone@05', 5, 'E');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `certificati`
--
ALTER TABLE `certificati`
  ADD PRIMARY KEY (`idc`);

--
-- Indici per le tabelle `ottenimento`
--
ALTER TABLE `ottenimento`
  ADD PRIMARY KEY (`chiave`),
  ADD KEY `idc_fk` (`idc_fk`),
  ADD KEY `cfs_fk` (`cfs_fk`);

--
-- Indici per le tabelle `studenti`
--
ALTER TABLE `studenti`
  ADD PRIMARY KEY (`cfs`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `certificati`
--
ALTER TABLE `certificati`
  MODIFY `idc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `ottenimento`
--
ALTER TABLE `ottenimento`
  MODIFY `chiave` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `ottenimento`
--
ALTER TABLE `ottenimento`
  ADD CONSTRAINT `ottenimento_ibfk_1` FOREIGN KEY (`idc_fk`) REFERENCES `certificati` (`idc`),
  ADD CONSTRAINT `ottenimento_ibfk_2` FOREIGN KEY (`cfs_fk`) REFERENCES `studenti` (`cfs`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
